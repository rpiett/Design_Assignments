# Design Assignment 1: Weather App

A Pen created on CodePen.io. Original URL: [https://codepen.io/ppietrus/pen/PoBaYxv](https://codepen.io/ppietrus/pen/PoBaYxv).

